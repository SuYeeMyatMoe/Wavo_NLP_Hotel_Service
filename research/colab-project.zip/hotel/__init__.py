"""Wavo hotel operations."""
